/*package com.example.vahsir.voteit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Host extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);
    }
}

*/
package com.example.vahsir.voteit;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.*;
        import java.lang.*;
        import java.util.*;
        import android.content.Intent;

        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;

        import static com.example.vahsir.voteit.R.layout.activity_host;

public class Host extends AppCompatActivity {


    private DatabaseReference dbr;
    private EditText ques, op1, op2, op3, op4, key;
    private Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);
        setTitle("HOST");


        save = (Button) findViewById(R.id.save);
        dbr = FirebaseDatabase.getInstance().getReference();
       // butpar();


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ques = (EditText)findViewById(R.id.ques);
                op1 = (EditText)findViewById(R.id.op1);
                op2 = (EditText)findViewById(R.id.op2);
                op3 = (EditText)findViewById(R.id.op3);
                op4 = (EditText)findViewById(R.id.op4);
                key = (EditText)findViewById(R.id.key);
                String quesStr = ques.getText().toString().trim();
                String op1Str = op1.getText().toString().trim();
                String op2Str = op2.getText().toString().trim();
                String op3Str = op3.getText().toString().trim();
                String op4Str = op4.getText ().toString().trim();
                String keyStr = key.getText().toString().trim();

                HashMap<String, String> dataMap = new HashMap<String, String>();
                dataMap.put("Question", quesStr);
                dataMap.put("Option1", op1Str);
                dataMap.put("Option2", op2Str);
                dataMap.put("Option3", op3Str);
                dataMap.put("Option4", op4Str);
                dataMap.put("Key", keyStr);
                dataMap.put("cntr1", "0");
                dataMap.put("cntr2", "0");
                dataMap.put("cntr3", "0");
                dataMap.put("cntr4", "0");
                DatabaseReference ref = dbr.child(keyStr);
                Discussion d = new Discussion(keyStr,op1Str,op2Str,op3Str,op4Str,quesStr);

                // dbr.push().setValue(dataMap);
                ref.setValue(d);
                op1.setText("");
                op2.setText("");
                op3.setText("");
                op4.setText("");
                key.setText("");
                ques.setText("");
                // dbr.child("Question").setValue(quesStr);
            }
        });
    }
}


  /*  public void butpar() {
        save = (Button)findViewById(R.id.save);
         save.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent sp = new Intent(Host.this, Result.class);
                        startActivity(sp);
                    }
                }
        );
    }*/

