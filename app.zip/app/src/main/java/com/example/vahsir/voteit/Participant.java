/*package com.example.vahsir.voteit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Participant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participant);
    }
}
*/

package com.example.vahsir.voteit;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.content.Intent;
        import android.util.*;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.RadioButton;
        import android.widget.RadioGroup;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.ValueEventListener;

public class Participant extends AppCompatActivity {

    DatabaseReference database;
    EditText key;
    Button btnSubmit;
    Discussion discussion;
    EditText ques, op1, op2, op3, op4;
    TextView quesText, op1Text, op2Text, op3Text, op4Text;
    String op1Str, op2Str, op3Str, op4Str, quesStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participant);
        setTitle("APPLICANT");

        // database = FirebaseDatabase.getInstance();
        key = (EditText)findViewById(R.id.key);
        btnSubmit = (Button)findViewById(R.id.btns);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quesText = (TextView)findViewById(R.id.ques);
                op1Text = (TextView)findViewById(R.id.op1);
                op2Text = (TextView)findViewById(R.id.op2);
                op3Text = (TextView)findViewById(R.id.op3);
                op4Text = (TextView)findViewById(R.id.op4);
                Log.i("AppTest>>>>", "onDataChange: clicked");
                //getData();
                // DatabaseReference dbr = database.getReference(key.getText().toString().trim());
                //key.getText().toString().trim()
                database = FirebaseDatabase.getInstance().getReference().child(key.getText().toString());;
                Log.i("AppTest>>>>", "onDataChange: clicked again");
                Log.i( " key" , key.getText().toString());
                database.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Log.i("AppTest>>>>", "onDataChange: entered");
                        if (dataSnapshot.hasChildren()) {
                            //discussion = dataSnapshot.getValue(Discussion.class);
                            op1Str = dataSnapshot.child("op1").getValue().toString();
                            op2Str = dataSnapshot.child("op2").getValue().toString();
                            op3Str = dataSnapshot.child("op3").getValue().toString();
                            op4Str = dataSnapshot.child("op4").getValue().toString();
                            quesStr = dataSnapshot.child("ques").getValue().toString();
                            quesText.setText(quesStr);
                            op1Text.setText(op1Str);
                            op2Text.setText(op2Str);
                            op3Text.setText(op3Str);
                            op4Text.setText(op4Str);
                        } else {
                            Toast.makeText(Participant.this, "Invalid Key!", Toast.LENGTH_SHORT).show();
                        }
                    }
  /*                  ValueEventListener eventListener = new ValueEventListener() {


                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    }
                    DatabaseReference usersRef.addListenerForSingleValueEvent(eventListener);
*/
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.i("AppTest>>>>", "onDataChange: end");
                    }
                });
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup group = (RadioGroup)findViewById(R.id.radioGroup);
                int selectedId = group.getCheckedRadioButtonId();
                RadioButton rb = (RadioButton)findViewById(selectedId);
                String option = rb.getText().toString();



            }
        });

    }



    public void displayData() {
        ques.setText(discussion.getQues());
        op1.setText(discussion.getOp1());
        op2.setText(discussion.getOp2());
        op3.setText(discussion.getOp3());
        op4.setText(discussion.getOp4());
    }
}

