/*package com.example.vahsir.voteit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
*/
package com.example.vahsir.voteit;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.widget.Button;
        import android.content.Intent;
        import android.app.Activity;
        import android.view.View;


public class MainActivity extends AppCompatActivity {
    public Button iphost;
    public Button ippart;
    public void buthost() {
        iphost = (Button)findViewById(R.id.iphost);
        iphost.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent ih = new Intent(MainActivity.this, Host.class);
                        startActivity(ih);
                    }
                }
        );
    }

    public void butpart() {
        ippart = (Button)findViewById(R.id.ippart);
        ippart.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent ip = new Intent(MainActivity.this, Participant.class);
                        startActivity(ip);
                    }
                }
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buthost();
        butpart();
    }
}

